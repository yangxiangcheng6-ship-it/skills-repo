import json
import datetime

def hello():
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    response = {
        'ok': True,
        'now': now
    }
    print(json.dumps(response))

if __name__ == '__main__':
    hello()