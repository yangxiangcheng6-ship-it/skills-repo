---
name: hello-gen
description: 输出问候语并反馈心情
---

# Hello Gen Skill

This skill generates a simple greeting and provides feedback on the mood.