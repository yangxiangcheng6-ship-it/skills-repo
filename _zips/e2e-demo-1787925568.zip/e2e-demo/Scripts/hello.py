import json
from datetime import datetime
def hello():
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return json.dumps({'ok': True, 'now': now})
if __name__ == '__main__':
    print(hello())