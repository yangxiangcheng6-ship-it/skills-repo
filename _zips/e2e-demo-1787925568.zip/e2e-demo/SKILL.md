---
name: e2e-demo
description: 运行一个 Python 脚本，输出包含当前日期时间的问候语 JSON，用于端到端验证
---
触发方式：直接运行 `Scripts/hello.py` 即可获取当前日期时间的问候语 JSON。