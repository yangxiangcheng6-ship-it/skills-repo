---
name: hello-gen
description: 输出问候语并反馈心情(更新版)
---

# Hello Gen Skill

此技能用于演示更新流程，能够输出问候语。