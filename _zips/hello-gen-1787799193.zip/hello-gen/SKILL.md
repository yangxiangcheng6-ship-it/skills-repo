---
name: hello-gen
description: 输出问候语并反馈心情(更新版v2)
---

# hello-gen

这是一个用于演示更新流程的技能包。