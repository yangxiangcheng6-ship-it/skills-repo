import json
import datetime

now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
print(json.dumps({'ok': True, 'now': now}))