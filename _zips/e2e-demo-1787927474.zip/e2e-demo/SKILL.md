---
name: e2e-demo
description: 运行一个 Python 脚本输出包含当前日期时间的问候语 JSON，用于端到端验证。
---

该技能通过运行 `Scripts/hello.py` 脚本来生成一个包含当前日期时间的问候语 JSON。这个示例主要用于演示如何构建和测试一个简单的技能。