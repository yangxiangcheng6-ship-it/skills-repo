---
name: hello-gen
description: 输出问候语并反馈心情 v3
---

# hello-gen

这是一个用于演示的技能包，主要功能是输出问候语。