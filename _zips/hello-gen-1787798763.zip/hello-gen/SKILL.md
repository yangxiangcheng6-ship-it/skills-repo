---
name: hello-gen
description: 输出问候语并反馈心情
---

# Hello Gen Skill

This skill outputs a greeting message and provides feedback on the mood.