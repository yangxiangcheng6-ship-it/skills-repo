---
name: e2e-demo
description: 运行一个 Python 脚本输出包含当前日期时间的问候语 JSON，用于端到端验证。
---
e2e-demo 技能通过运行 Scripts/hello.py 脚本来生成一个包含当前日期时间的问候语 JSON。这个技能主要用于端到端的验证过程。