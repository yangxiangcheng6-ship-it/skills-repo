import json
from datetime import datetime
def generate_greeting():
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    greeting = {
        'message': f'Hello, the current date and time is {current_time}',
        'timestamp': current_time
    }
    return json.dumps(greeting, ensure_ascii=False)
if __name__ == '__main__':
    print(generate_greeting())